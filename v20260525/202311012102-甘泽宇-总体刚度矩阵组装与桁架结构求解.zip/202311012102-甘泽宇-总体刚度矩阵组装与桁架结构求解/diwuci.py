import numpy as np
import json


class TrussFEA:
    def __init__(self):
        # 基础参数
        self.nsd = None  # 空间维数
        self.ndof = None  # 单节点自由度
        self.nnp = None  # 节点总数
        self.nel = None  # 单元总数
        self.nen = 2  # 单单元节点数

        # 模型数据
        self.E = None
        self.A = None
        self.nodes = None
        self.IEN = None

        # 边界与载荷
        self.fixed_dof = None
        self.fixed_val = None
        self.force_dof = None
        self.force_val = None

        # 结果
        self.LM = None
        self.K = None
        self.d = None
        self.f = None
        self.stress = None
        self.force_elem = None

    def load_json(self, filename):
        """加载JSON输入文件"""
        with open(filename, 'r') as f:
            data = json.load(f)

        self.nsd = data['nsd']
        self.ndof = data['ndof']
        self.nnp = data['nnp']
        self.nel = data['nel']
        self.nen = data['nen']

        self.E = np.array(data['E'])
        self.A = np.array(data['CArea'])

        # 节点坐标
        if self.nsd == 1:
            self.nodes = np.array(data['x']).reshape(-1, 1)
        else:
            self.nodes = np.column_stack([data['x'], data['y']])

        self.IEN = np.array(data['IEN']) - 1  # 转0基

        # 边界条件转0基
        self.fixed_dof = np.array(data['fixed_dof']) - 1
        self.fixed_val = np.array(data['fixed_value'])
        self.force_dof = np.array(data['force_dof']) - 1
        self.force_val = np.array(data['force_value'])

        print(f"模型：{data['Title']}")
        print(f"节点：{self.nnp} | 单元：{self.nel} | 总自由度：{self.nnp * self.ndof}")

    def generate_LM(self):
        """自动生成对号矩阵LM"""
        n_dof_elem = self.nen * self.ndof
        self.LM = np.zeros((n_dof_elem, self.nel), dtype=int)

        for e in range(self.nel):
            n1, n2 = self.IEN[e]
            dof1 = n1 * self.ndof + np.arange(self.ndof)
            dof2 = n2 * self.ndof + np.arange(self.ndof)
            self.LM[:, e] = np.hstack([dof1, dof2])

        print("\n对号矩阵 LM：")
        print(self.LM)
        return self.LM

    def compute_element_stiffness(self, e):
        """单元刚度矩阵计算"""
        n1, n2 = self.IEN[e]
        x1, x2 = self.nodes[n1], self.nodes[n2]
        dx = x2 - x1
        L = np.linalg.norm(dx)
        c = dx / L if L > 1e-12 else np.zeros_like(dx)

        if self.nsd == 1:
            ke = self.E[e] * self.A[e] / L * np.array([[1, -1], [-1, 1]])
        else:
            c1, c2 = c
            k = self.E[e] * self.A[e] / L
            ke = k * np.array([
                [c1 ** 2, c1 * c2, -c1 ** 2, -c1 * c2],
                [c1 * c2, c2 ** 2, -c1 * c2, -c2 ** 2],
                [-c1 ** 2, -c1 * c2, c1 ** 2, c1 * c2],
                [-c1 * c2, -c2 ** 2, c1 * c2, c2 ** 2]
            ])
        return ke, L, c

    def assemble_stiffness(self):
        """直接组装总体刚度矩阵"""
        nd = self.nnp * self.ndof
        self.K = np.zeros((nd, nd))

        for e in range(self.nel):
            ke, _, _ = self.compute_element_stiffness(e)
            lm = self.LM[:, e]
            for i in range(len(lm)):
                for j in range(len(lm)):
                    self.K[lm[i], lm[j]] += ke[i, j]

        print("\n总体刚度矩阵 K：")
        np.set_printoptions(precision=4, suppress=True)
        print(self.K)
        print(f"对称：{np.allclose(self.K, self.K.T)}")
        print(f"奇异：{abs(np.linalg.det(self.K)) < 1e-10}")
        return self.K

    def apply_bc_and_solve(self):
        """缩减法处理边界条件并求解"""
        nd = self.nnp * self.ndof
        self.f = np.zeros(nd)
        self.f[self.force_dof] = self.force_val

        free_dof = np.setdiff1d(range(nd), self.fixed_dof)
        fix_dof = self.fixed_dof

        KFF = self.K[np.ix_(free_dof, free_dof)]
        KEF = self.K[np.ix_(fix_dof, free_dof)]
        fF = self.f[free_dof]
        dE = self.fixed_val

        dF = np.linalg.solve(KFF, fF - KEF.T @ dE)

        self.d = np.zeros(nd)
        self.d[free_dof] = dF
        self.d[fix_dof] = dE

        print("\n节点位移：")
        print(self.d)

        reaction = self.K @ self.d - self.f
        print("\n约束反力：")
        for i, dof in enumerate(fix_dof):
            print(f"自由度{dof + 1}：{reaction[dof]:.6f}")
        return self.d

    def postprocess(self):
        """后处理：应力、轴力、长度、方向余弦"""
        self.stress = np.zeros(self.nel)
        self.force_elem = np.zeros(self.nel)

        print("\n===== 单元计算结果 =====")
        for e in range(self.nel):
            ke, L, c = self.compute_element_stiffness(e)
            de = self.d[self.LM[:, e]]

            if self.nsd == 1:
                sig = self.E[e] / L * np.array([-1, 1]) @ de
            else:
                sig = self.E[e] / L * np.array([-c[0], -c[1], c[0], c[1]]) @ de

            self.stress[e] = sig
            self.force_elem[e] = sig * self.A[e]

            print(f"\n单元{e + 1}：")
            print(f"  长度：{L:.6f}")
            print(f"  方向余弦：{c}")
            print(f"  应力：{sig:.6f}")
            print(f"  轴力：{self.force_elem[e]:.6f}")

    def solve(self):
        """完整有限元流程"""
        print("\n===== 有限元求解开始 =====")
        self.generate_LM()
        self.assemble_stiffness()
        self.apply_bc_and_solve()
        self.postprocess()
        print("===== 求解完成 =====")


# ------------------------------
# 算例1：一维两单元杆
# ------------------------------
def run_example_1d():
    data = {
        "Title": "1D two-element bar",
        "nsd": 1, "ndof": 1, "nnp": 3, "nel": 2, "nen": 2,
        "E": [100, 200], "CArea": [1, 1],
        "x": [0, 1, 2],
        "IEN": [[1, 2], [2, 3]],
        "fixed_dof": [1], "fixed_value": [0.0],
        "force_dof": [3], "force_value": [10.0]
    }
    with open("input_1d.json", "w") as f:
        json.dump(data, f, indent=2)

    fea = TrussFEA()
    fea.load_json("input_1d.json")
    fea.solve()


# ------------------------------
# 算例2：二维两杆桁架
# ------------------------------
def run_example_2d():
    data = {
        "Title": "2D truss example",
        "nsd": 2, "ndof": 2, "nnp": 3, "nel": 2, "nen": 2,
        "E": [1, 1], "CArea": [1, 1],
        "x": [1, 0, 1], "y": [0, 0, 1],
        "IEN": [[1, 3], [2, 3]],
        "fixed_dof": [1, 2, 3, 4], "fixed_value": [0, 0, 0, 0],
        "force_dof": [5, 6], "force_value": [10, 0]
    }
    with open("input_2d.json", "w") as f:
        json.dump(data, f, indent=2)

    fea = TrussFEA()
    fea.load_json("input_2d.json")
    fea.solve()


if __name__ == "__main__":
    print("========== 算例1：一维杆 ==========")
    run_example_1d()
    print("\n\n========== 算例2：二维桁架 ==========")
    run_example_2d()