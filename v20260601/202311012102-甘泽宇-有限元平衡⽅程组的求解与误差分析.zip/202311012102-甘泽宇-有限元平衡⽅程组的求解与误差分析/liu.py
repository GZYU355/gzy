"""
有限元平衡方程组求解器
学号: 202311012102
姓名: 甘泽宇
作业: 2.4 平衡方程组求解程序设计
"""

import numpy as np
import json
import time
import os
from scipy.sparse import csr_matrix, coo_matrix
from scipy.sparse.linalg import spsolve
import matplotlib.pyplot as plt


class LDLTSolver:
    """
    任务1: 稠密矩阵LDL^T求解器
    实现对称正定矩阵的LDL^T分解和求解
    """

    @staticmethod
    def ldlt_factor(K):
        """
        LDL^T分解
        K = L * D * L^T
        其中L为单位下三角矩阵，D为对角矩阵

        参数:
            K: 对称正定矩阵 (n x n)

        返回:
            L: 单位下三角矩阵 (n x n)
            D: 对角矩阵 (n x n)

        异常:
            ValueError: 当出现非正主元时
        """
        K = np.array(K, dtype=float)
        n = K.shape[0]

        # 检查对称性
        if not np.allclose(K, K.T):
            print("警告: 矩阵不对称，将强制对称化")
            K = (K + K.T) / 2

        # 初始化L和D
        L = np.eye(n)
        D = np.zeros((n, n))

        # 使用紧凑存储的LDL^T分解
        LDu = K.copy()

        for j in range(n):
            # 检查主元
            if LDu[j, j] <= 0:
                raise ValueError(f"矩阵非正定或存在零主元: D[{j},{j}] = {LDu[j, j]:.6e} <= 0")

            D[j, j] = LDu[j, j]

            # 计算第j列的下三角部分
            for i in range(j + 1, n):
                L[i, j] = LDu[i, j] / D[j, j]

            # 更新剩余子矩阵
            for k in range(j + 1, n):
                for i in range(k, n):
                    LDu[i, k] -= L[i, j] * D[j, j] * L[k, j]

        return L, D

    @staticmethod
    def ldlt_solve(L, D, R):
        """
        使用LDL^T分解求解方程组 K * a = R

        求解步骤:
        1. 前代: L * y = R
        2. 对角求解: D * z = y
        3. 回代: L^T * a = z

        参数:
            L: 单位下三角矩阵
            D: 对角矩阵
            R: 右端项向量

        返回:
            a: 解向量
        """
        R = np.array(R, dtype=float)
        n = len(R)
        y = np.zeros(n)
        z = np.zeros(n)
        a = np.zeros(n)

        # 步骤1: 前代法求解 L * y = R
        for i in range(n):
            y[i] = R[i]
            for j in range(i):
                y[i] -= L[i, j] * y[j]

        # 步骤2: 对角求解 D * z = y
        for i in range(n):
            if D[i, i] == 0:
                raise ValueError(f"对角元素为零: D[{i},{i}] = 0")
            z[i] = y[i] / D[i, i]

        # 步骤3: 回代法求解 L^T * a = z
        for i in range(n - 1, -1, -1):
            a[i] = z[i]
            for j in range(i + 1, n):
                a[i] -= L[j, i] * a[j]

        return a

    @staticmethod
    def solve(K, R, check_positive=True):
        """完整的LDL^T求解流程"""
        L, D = LDLTSolver.ldlt_factor(K)
        a = LDLTSolver.ldlt_solve(L, D, R)
        return a, L, D

    @staticmethod
    def residual_norm(K, a, R):
        """计算残差和残差范数"""
        r = R - K @ a
        norm_r = np.linalg.norm(r)
        norm_R = np.linalg.norm(R)
        relative_residual = norm_r / norm_R if norm_R > 0 else 0
        return r, norm_r, relative_residual


class ConditionNumberAnalyzer:
    """任务2: 条件数分析器"""

    @staticmethod
    def compute_condition_number(K, norm_type=2):
        """计算矩阵的条件数"""
        K_inv = np.linalg.inv(K)
        cond = np.linalg.norm(K, norm_type) * np.linalg.norm(K_inv, norm_type)
        return cond

    @staticmethod
    def analyze_ill_conditioned():
        """病态线性方程组分析"""
        print("\n" + "=" * 60)
        print("任务2: 病态线性方程组分析")
        print("=" * 60)

        K = np.array([[1.0000, 1.0000],
                      [1.0000, 1.0001]], dtype=float)
        a_exact = np.array([1.0, 1.0])
        R = K @ a_exact

        cond = ConditionNumberAnalyzer.compute_condition_number(K)
        print(f"\n矩阵条件数: {cond:.6e}")
        print(f"说明: 条件数 > 10^3 表示矩阵病态")

        # 双精度计算
        print("\n--- 双精度计算 ---")
        a_double, _, _ = LDLTSolver.solve(K, R)
        _, _, rel_res_double = LDLTSolver.residual_norm(K, a_double, R)
        rel_err_double = np.linalg.norm(a_double - a_exact) / np.linalg.norm(a_exact)

        print(f"数值解: {a_double}")
        print(f"相对残差: {rel_res_double:.6e}")
        print(f"相对误差: {rel_err_double:.6e}")

        # 单精度模拟
        print("\n--- 单精度模拟 ---")
        K_single = K.astype(np.float32)
        R_single = R.astype(np.float32)

        try:
            a_single, _, _ = LDLTSolver.solve(K_single, R_single)
            _, _, rel_res_single = LDLTSolver.residual_norm(K_single, a_single, R_single)
            rel_err_single = np.linalg.norm(a_single - a_exact) / np.linalg.norm(a_exact)

            print(f"数值解: {a_single}")
            print(f"相对残差: {rel_res_single:.6e}")
            print(f"相对误差: {rel_err_single:.6e}")
        except ValueError as e:
            print(f"分解失败: {e}")

        print("\n" + "-" * 40)
        print("分析结论:")
        print("对于病态问题(条件数很大), 残差小并不一定说明解准确.")
        print(f"原因: 条件数放大了输入数据的误差和舍入误差.")
        print(f"理论误差上界: 相对误差 ≤ 条件数 × 相对残差")

        return cond


class SparseSolverInterface:
    """任务3: 大规模稀疏方程组求解器接口"""

    @staticmethod
    def to_csr(K, tol=1e-12):
        """将稠密矩阵转换为CSR稀疏格式"""
        n = K.shape[0]
        rows, cols, vals = [], [], []

        for i in range(n):
            for j in range(n):
                if abs(K[i, j]) > tol:
                    rows.append(i)
                    cols.append(j)
                    vals.append(K[i, j])

        return csr_matrix((vals, (rows, cols)), shape=(n, n))

    @staticmethod
    def solve_sparse(K_sparse, R, solver_name="scipy"):
        """使用稀疏求解器求解"""
        R = np.array(R, dtype=float)
        start_time = time.time()
        a = spsolve(K_sparse, R)
        solve_time = time.time() - start_time
        return a, solve_time

    @staticmethod
    def get_sparse_info(K_sparse):
        """获取稀疏矩阵信息"""
        n = K_sparse.shape[0]
        nnz = K_sparse.nnz
        density = nnz / (n * n) * 100
        return {'n': n, 'nnz': nnz, 'density': density}


class TrussFEAWithSolver:
    """
    扩展的有限元分析类
    集成LDLT求解器和稀疏求解器
    """

    def __init__(self):
        self.nsd = None  # 空间维数
        self.ndof = None  # 单节点自由度
        self.nnp = None  # 节点总数
        self.nel = None  # 单元总数
        self.nen = 2  # 单单元节点数

        self.E = None  # 弹性模量
        self.A = None  # 截面积
        self.nodes = None  # 节点坐标
        self.IEN = None  # 单元连接矩阵

        self.fixed_dof = None  # 固定自由度
        self.fixed_val = None  # 固定位移值
        self.force_dof = None  # 受力自由度
        self.force_val = None  # 力值

        self.LM = None  # 对号矩阵
        self.K = None  # 总体刚度矩阵
        self.K_sparse = None  # 稀疏格式刚度矩阵
        self.d = None  # 位移向量
        self.f = None  # 外力向量
        self.stress = None  # 单元应力
        self.force_elem = None  # 单元轴力
        self.reaction = None  # 约束反力

        self.assembly_time = 0
        self.solve_time = 0
        self.solver_name = ""

    def load_json(self, filename):
        """加载JSON输入文件"""
        with open(filename, 'r') as f:
            data = json.load(f)

        self.nsd = data['nsd']
        self.ndof = data['ndof']
        self.nnp = data['nnp']
        self.nel = data['nel']
        self.nen = data['nen']

        self.E = np.array(data['E'])
        self.A = np.array(data.get('CArea', data.get('A', [1] * self.nel)))

        # 节点坐标
        if self.nsd == 1:
            self.nodes = np.array(data['x']).reshape(-1, 1)
        else:
            x = data.get('x', [])
            y = data.get('y', [])
            if len(x) > 0 and len(y) > 0:
                self.nodes = np.column_stack([x, y])
            elif 'coords' in data:
                self.nodes = np.array(data['coords'])
            else:
                self.nodes = np.zeros((self.nnp, self.nsd))

        self.IEN = np.array(data['IEN']) - 1  # 转0基

        self.fixed_dof = np.array(data['fixed_dof']) - 1
        self.fixed_val = np.array(data['fixed_value'])
        self.force_dof = np.array(data['force_dof']) - 1
        self.force_val = np.array(data['force_value'])

        print(f"模型: {data.get('Title', 'Unknown')}")
        print(f"节点: {self.nnp} | 单元: {self.nel} | 总自由度: {self.nnp * self.ndof}")

    def generate_LM(self):
        """自动生成对号矩阵LM"""
        n_dof_elem = self.nen * self.ndof
        self.LM = np.zeros((n_dof_elem, self.nel), dtype=int)

        for e in range(self.nel):
            n1, n2 = self.IEN[e]
            dof1 = n1 * self.ndof + np.arange(self.ndof)
            dof2 = n2 * self.ndof + np.arange(self.ndof)
            self.LM[:, e] = np.hstack([dof1, dof2])

        print("\n对号矩阵 LM (前5列):")
        print(self.LM[:, :min(5, self.nel)])
        return self.LM

    def compute_element_stiffness(self, e):
        """单元刚度矩阵计算"""
        n1, n2 = self.IEN[e]
        x1 = self.nodes[n1]
        x2 = self.nodes[n2]
        dx = x2 - x1
        L = np.linalg.norm(dx)

        if L < 1e-12:
            return np.zeros((self.ndof * 2, self.ndof * 2)), L, np.zeros(self.nsd)

        c = dx / L

        if self.nsd == 1:
            k = self.E[e] * self.A[e] / L
            ke = k * np.array([[1, -1], [-1, 1]])
        else:
            k = self.E[e] * self.A[e] / L
            # 修复: 正确处理方向余弦
            if self.nsd == 2:
                c1 = c[0]
                c2 = c[1] if len(c) > 1 else 0.0
                ke = k * np.array([
                    [c1 * c1, c1 * c2, -c1 * c1, -c1 * c2],
                    [c1 * c2, c2 * c2, -c1 * c2, -c2 * c2],
                    [-c1 * c1, -c1 * c2, c1 * c1, c1 * c2],
                    [-c1 * c2, -c2 * c2, c1 * c2, c2 * c2]
                ])
            else:
                # 3D情况
                c1, c2, c3 = c[0], c[1] if len(c) > 1 else 0, c[2] if len(c) > 2 else 0
                ke = k * np.array([
                    [c1 * c1, c1 * c2, c1 * c3, -c1 * c1, -c1 * c2, -c1 * c3],
                    [c1 * c2, c2 * c2, c2 * c3, -c1 * c2, -c2 * c2, -c2 * c3],
                    [c1 * c3, c2 * c3, c3 * c3, -c1 * c3, -c2 * c3, -c3 * c3],
                    [-c1 * c1, -c1 * c2, -c1 * c3, c1 * c1, c1 * c2, c1 * c3],
                    [-c1 * c2, -c2 * c2, -c2 * c3, c1 * c2, c2 * c2, c2 * c3],
                    [-c1 * c3, -c2 * c3, -c3 * c3, c1 * c3, c2 * c3, c3 * c3]
                ])

        return ke, L, c

    def assemble_stiffness(self, use_sparse=False):
        """组装总体刚度矩阵"""
        nd = self.nnp * self.ndof
        start_time = time.time()

        if use_sparse:
            rows, cols, vals = [], [], []

            for e in range(self.nel):
                ke, _, _ = self.compute_element_stiffness(e)
                lm = self.LM[:, e]
                n_dof = len(lm)

                for i in range(n_dof):
                    for j in range(n_dof):
                        if abs(ke[i, j]) > 1e-12:
                            rows.append(lm[i])
                            cols.append(lm[j])
                            vals.append(ke[i, j])

            self.K_sparse = coo_matrix((vals, (rows, cols)), shape=(nd, nd)).tocsr()
            self.K = None
        else:
            self.K = np.zeros((nd, nd))

            for e in range(self.nel):
                ke, _, _ = self.compute_element_stiffness(e)
                lm = self.LM[:, e]
                for i in range(len(lm)):
                    for j in range(len(lm)):
                        self.K[lm[i], lm[j]] += ke[i, j]

            self.K_sparse = None

        self.assembly_time = time.time() - start_time

        if not use_sparse and self.K is not None and nd < 20:
            print(f"\n总体刚度矩阵 K:")
            np.set_printoptions(precision=4, suppress=True)
            print(self.K)
            print(f"对称性: {np.allclose(self.K, self.K.T)}")

        return self.K if not use_sparse else self.K_sparse

    def apply_bc_and_solve(self, method="ldlt", use_sparse=False):
        """处理边界条件并求解"""
        nd = self.nnp * self.ndof

        self.f = np.zeros(nd)
        self.f[self.force_dof] = self.force_val

        free_dof = np.setdiff1d(range(nd), self.fixed_dof)
        fix_dof = self.fixed_dof

        if use_sparse and self.K_sparse is not None:
            K_FF = self.K_sparse[free_dof, :][:, free_dof]
            K_EF = self.K_sparse[fix_dof, :][:, free_dof]
            fF = self.f[free_dof]
            dE = self.fixed_val

            rhs = fF - K_EF.T @ dE

            start_time = time.time()
            a_free, _ = SparseSolverInterface.solve_sparse(K_FF, rhs, "scipy")
            self.solve_time = time.time() - start_time
            self.solver_name = "scipy.sparse.spsolve"

            self.d = np.zeros(nd)
            self.d[free_dof] = a_free
            self.d[fix_dof] = dE
            self.reaction = self.K_sparse @ self.d - self.f
        else:
            K_FF = self.K[np.ix_(free_dof, free_dof)]
            K_EF = self.K[np.ix_(fix_dof, free_dof)]
            fF = self.f[free_dof]
            dE = self.fixed_val

            rhs = fF - K_EF.T @ dE

            start_time = time.time()
            if method == "ldlt":
                try:
                    a_free, _, _ = LDLTSolver.solve(K_FF, rhs)
                    self.solver_name = "LDLT (custom)"
                except ValueError as e:
                    print(f"LDLT分解失败: {e}")
                    a_free = np.linalg.solve(K_FF, rhs)
                    self.solver_name = "numpy.linalg.solve (fallback)"
            else:
                a_free = np.linalg.solve(K_FF, rhs)
                self.solver_name = "numpy.linalg.solve"

            self.solve_time = time.time() - start_time

            self.d = np.zeros(nd)
            self.d[free_dof] = a_free
            self.d[fix_dof] = dE
            self.reaction = self.K @ self.d - self.f

        print(f"\n求解器: {self.solver_name}")
        print(f"装配时间: {self.assembly_time:.6f} s")
        print(f"求解时间: {self.solve_time:.6f} s")

        # 移除残差打印
        # if not use_sparse and self.K is not None:
        #     _, _, rel_res = LDLTSolver.residual_norm(self.K, self.d, self.f)
        #     print(f"相对残差: {rel_res:.6e}")
        # elif self.K_sparse is not None:
        #     r = self.f - self.K_sparse @ self.d
        #     rel_res = np.linalg.norm(r) / np.linalg.norm(self.f) if np.linalg.norm(self.f) > 0 else 0
        #     print(f"相对残差: {rel_res:.6e}")

        print("\n节点位移:")
        np.set_printoptions(precision=6)
        print(self.d)

        print("\n约束反力 (固定自由度):")
        for i, dof in enumerate(fix_dof):
            print(f"  自由度 {dof + 1}: {self.reaction[dof]:.6f}")

        return self.d

    def postprocess(self):
        """后处理: 应力、轴力"""
        self.stress = np.zeros(self.nel)
        self.force_elem = np.zeros(self.nel)

        print("\n" + "=" * 50)
        print("单元计算结果")
        print("=" * 50)

        for e in range(self.nel):
            ke, L, c = self.compute_element_stiffness(e)
            de = self.d[self.LM[:, e]]

            if self.nsd == 1:
                sig = self.E[e] / L * np.array([-1, 1]) @ de
            else:
                # 应力 = E/L * [-c1, -c2, c1, c2] * de
                if len(c) >= 2:
                    sig = self.E[e] / L * np.array([-c[0], -c[1], c[0], c[1]]) @ de
                else:
                    sig = self.E[e] / L * np.array([-c[0], 0, c[0], 0]) @ de

            self.stress[e] = sig
            self.force_elem[e] = sig * self.A[e] if isinstance(self.A, (np.ndarray, list)) else sig * self.A

            print(f"\n单元 {e + 1}:")
            print(f"  长度: {L:.6f}")
            print(f"  方向余弦: {c}")
            print(f"  应力: {sig:.6f}")
            print(f"  轴力: {self.force_elem[e]:.6f}")

        return self.stress, self.force_elem

    def solve(self, method="ldlt", use_sparse=False):
        """完整有限元求解流程"""
        print("\n" + "=" * 60)
        print("有限元求解开始")
        print("=" * 60)

        self.generate_LM()
        self.assemble_stiffness(use_sparse=use_sparse)
        self.apply_bc_and_solve(method=method, use_sparse=use_sparse)
        self.postprocess()

        print("\n" + "=" * 60)
        print("求解完成")
        print("=" * 60)

        return self.d


class PoissonFEMSolver:
    """二维Poisson方程有限元求解器"""

    def __init__(self, nx, ny, use_sparse=True):
        self.nx = nx
        self.ny = ny
        self.use_sparse = use_sparse

        self.nx_nodes = nx + 1
        self.ny_nodes = ny + 1
        self.n_nodes = self.nx_nodes * self.ny_nodes
        self.n_elements = nx * ny

        self.Lx = 1.0
        self.Ly = 1.0
        self.hx = self.Lx / nx
        self.hy = self.Ly / ny

        self.nodes = None
        self.IEN = None
        self.K = None
        self.R = None
        self.d = None

        self.assembly_time = 0
        self.solve_time = 0
        self.solver_name = ""

        self._generate_mesh()

    def _generate_mesh(self):
        """生成均匀网格"""
        x = np.linspace(0, self.Lx, self.nx_nodes)
        y = np.linspace(0, self.Ly, self.ny_nodes)
        X, Y = np.meshgrid(x, y)
        self.nodes = np.column_stack([X.flatten(), Y.flatten()])

        self.IEN = []
        for i in range(self.nx):
            for j in range(self.ny):
                n1 = j * self.nx_nodes + i
                n2 = j * self.nx_nodes + i + 1
                n3 = (j + 1) * self.nx_nodes + i + 1
                n4 = (j + 1) * self.nx_nodes + i
                self.IEN.append([n1, n2, n3, n4])

        self.IEN = np.array(self.IEN)

        print(f"\n网格信息:")
        print(f"  单元类型: Q4 (双线性四边形)")
        print(f"  节点数: {self.n_nodes}")
        print(f"  单元数: {self.n_elements}")
        print(f"  网格: {self.nx} x {self.ny}")

    def exact_solution(self, x, y):
        """精确解 u = sin(pi*x) * sin(pi*y)"""
        return np.sin(np.pi * x) * np.sin(np.pi * y)

    def source_term(self, x, y):
        """源项 f = 2*pi^2 * sin(pi*x) * sin(pi*y)"""
        return 2 * np.pi ** 2 * np.sin(np.pi * x) * np.sin(np.pi * y)

    def shape_functions(self, xi, eta):
        """Q4单元形函数及其导数"""
        N = np.array([
            (1 - xi) * (1 - eta) / 4,
            (1 + xi) * (1 - eta) / 4,
            (1 + xi) * (1 + eta) / 4,
            (1 - xi) * (1 + eta) / 4
        ])

        dN_dxi = np.array([
            [-(1 - eta) / 4, -(1 - xi) / 4],
            [(1 - eta) / 4, -(1 + xi) / 4],
            [(1 + eta) / 4, (1 + xi) / 4],
            [-(1 + eta) / 4, (1 - xi) / 4]
        ])

        return N, dN_dxi

    def compute_element_matrices(self, e):
        """计算单元刚度矩阵和载荷向量"""
        gauss_points = np.array([-1 / np.sqrt(3), 1 / np.sqrt(3)])
        gauss_weights = np.array([1, 1])

        ke = np.zeros((4, 4))
        fe = np.zeros(4)

        nodes = self.IEN[e]
        x_coords = self.nodes[nodes, 0]
        y_coords = self.nodes[nodes, 1]

        for i in range(2):
            xi = gauss_points[i]
            wi = gauss_weights[i]
            for j in range(2):
                eta = gauss_points[j]
                wj = gauss_weights[j]

                N, dN_dxi = self.shape_functions(xi, eta)

                J = np.zeros((2, 2))
                for k in range(4):
                    J[0, 0] += dN_dxi[k, 0] * x_coords[k]
                    J[0, 1] += dN_dxi[k, 0] * y_coords[k]
                    J[1, 0] += dN_dxi[k, 1] * x_coords[k]
                    J[1, 1] += dN_dxi[k, 1] * y_coords[k]

                detJ = np.linalg.det(J)
                invJ = np.linalg.inv(J)

                dN_dx = np.zeros((4, 2))
                for k in range(4):
                    dN_dx[k] = invJ @ dN_dxi[k]

                for k in range(4):
                    for l in range(4):
                        ke[k, l] += (dN_dx[k, 0] * dN_dx[l, 0] +
                                     dN_dx[k, 1] * dN_dx[l, 1]) * detJ * wi * wj

                x_phys = sum(N[k] * x_coords[k] for k in range(4))
                y_phys = sum(N[k] * y_coords[k] for k in range(4))
                f_val = self.source_term(x_phys, y_phys)

                for k in range(4):
                    fe[k] += N[k] * f_val * detJ * wi * wj

        return ke, fe

    def assemble_system(self):
        """组装总体刚度矩阵和载荷向量"""
        ndof = self.n_nodes
        start_time = time.time()

        if self.use_sparse:
            rows, cols, vals = [], [], []
            self.R = np.zeros(ndof)

            for e in range(self.n_elements):
                ke, fe = self.compute_element_matrices(e)
                nodes = self.IEN[e]

                for i in range(4):
                    for j in range(4):
                        if abs(ke[i, j]) > 1e-15:
                            rows.append(nodes[i])
                            cols.append(nodes[j])
                            vals.append(ke[i, j])

                for i in range(4):
                    self.R[nodes[i]] += fe[i]

            self.K = coo_matrix((vals, (rows, cols)), shape=(ndof, ndof)).tocsr()
        else:
            self.K = np.zeros((ndof, ndof))
            self.R = np.zeros(ndof)

            for e in range(self.n_elements):
                ke, fe = self.compute_element_matrices(e)
                nodes = self.IEN[e]

                for i in range(4):
                    for j in range(4):
                        self.K[nodes[i], nodes[j]] += ke[i, j]

                for i in range(4):
                    self.R[nodes[i]] += fe[i]

        self.assembly_time = time.time() - start_time
        print(f"\n装配完成: {self.assembly_time:.4f} s")

    def apply_dirichlet_bc(self):
        """施加零Dirichlet边界条件"""
        boundary_nodes = set()

        for i in range(self.nx_nodes):
            boundary_nodes.add(i)
            boundary_nodes.add(self.n_nodes - self.nx_nodes + i)

        for j in range(self.ny_nodes):
            boundary_nodes.add(j * self.nx_nodes)
            boundary_nodes.add(j * self.nx_nodes + self.nx_nodes - 1)

        boundary_nodes = list(boundary_nodes)
        free_nodes = [i for i in range(self.n_nodes) if i not in boundary_nodes]

        if self.use_sparse:
            K_FF = self.K[free_nodes, :][:, free_nodes]
            R_F = self.R[free_nodes]

            start_time = time.time()
            d_F = spsolve(K_FF, R_F)
            self.solve_time = time.time() - start_time
            self.solver_name = "scipy.sparse.spsolve"
        else:
            K_FF = self.K[np.ix_(free_nodes, free_nodes)]
            R_F = self.R[free_nodes]

            start_time = time.time()
            try:
                d_F = np.linalg.solve(K_FF, R_F)
                self.solver_name = "numpy.linalg.solve"
            except:
                d_F, _, _ = LDLTSolver.solve(K_FF, R_F)
                self.solver_name = "LDLT (custom)"
            self.solve_time = time.time() - start_time

        self.d = np.zeros(self.n_nodes)
        self.d[free_nodes] = d_F
        self.d[boundary_nodes] = 0

        print(f"边界条件: Dirichlet (u=0)")
        print(f"求解器: {self.solver_name}")
        print(f"求解时间: {self.solve_time:.4f} s")

        # 移除残差打印
        # if self.use_sparse:
        #     r = self.R - self.K @ self.d
        #     rel_res = np.linalg.norm(r) / np.linalg.norm(self.R) if np.linalg.norm(self.R) > 0 else 0
        # else:
        #     r = self.R - self.K @ self.d
        #     rel_res = np.linalg.norm(r) / np.linalg.norm(self.R) if np.linalg.norm(self.R) > 0 else 0
        # print(f"相对残差: {rel_res:.6e}")

        return self.d

    def compute_errors(self):
        """计算误差"""
        exact = np.array([self.exact_solution(x, y) for x, y in self.nodes])
        error = exact - self.d

        max_error = np.max(np.abs(error))
        l2_error = np.sqrt(np.sum(error ** 2))
        l2_exact = np.sqrt(np.sum(exact ** 2))
        rel_l2_error = l2_error / l2_exact if l2_exact > 0 else 0

        print(f"\n误差分析:")
        print(f"  最大节点误差: {max_error:.6e}")
        print(f"  离散L2相对误差: {rel_l2_error:.6e}")

        return max_error, rel_l2_error, error, exact

    def plot_solution(self, save_path=None):
        """绘制数值解云图"""
        X = self.nodes[:, 0].reshape(self.nx_nodes, self.ny_nodes)
        Y = self.nodes[:, 1].reshape(self.nx_nodes, self.ny_nodes)
        U = self.d.reshape(self.nx_nodes, self.ny_nodes)
        U_exact = np.array([self.exact_solution(x, y) for x, y in self.nodes]).reshape(self.nx_nodes, self.ny_nodes)
        Error = np.abs(U_exact - U)

        fig, axes = plt.subplots(1, 3, figsize=(15, 4))

        im1 = axes[0].contourf(X, Y, U, levels=20, cmap='jet')
        axes[0].set_title(f'Numerical Solution (nx={self.nx})')
        axes[0].set_xlabel('x')
        axes[0].set_ylabel('y')
        plt.colorbar(im1, ax=axes[0])

        im2 = axes[1].contourf(X, Y, U_exact, levels=20, cmap='jet')
        axes[1].set_title('Exact Solution')
        axes[1].set_xlabel('x')
        axes[1].set_ylabel('y')
        plt.colorbar(im2, ax=axes[1])

        im3 = axes[2].contourf(X, Y, Error, levels=20, cmap='hot')
        axes[2].set_title('Absolute Error')
        axes[2].set_xlabel('x')
        axes[2].set_ylabel('y')
        plt.colorbar(im3, ax=axes[2])

        plt.tight_layout()

        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            print(f"图已保存: {save_path}")

        plt.show()

        return fig

    def solve(self):
        """完整求解流程"""
        print("\n" + "=" * 60)
        print("二维Poisson方程有限元求解")
        print("=" * 60)
        print(f"理论解: u(x,y) = sin(pi*x) * sin(pi*y)")

        self.assemble_system()

        if self.use_sparse:
            info = SparseSolverInterface.get_sparse_info(self.K)
            print(f"  非零元数: {info['nnz']}")
            print(f"  稀疏度: {info['density']:.4f}%")

        self.apply_dirichlet_bc()
        max_error, rel_l2_error, error, exact = self.compute_errors()

        return self.d, max_error, rel_l2_error


def run_tridiagonal_test():
    """算例1: 三对角对称正定矩阵测试"""
    print("\n" + "=" * 60)
    print("算例1: 三对角对称正定矩阵测试")
    print("=" * 60)

    sizes = [10, 100, 500]

    for n in sizes:
        print(f"\n--- n = {n} ---")

        K = np.zeros((n, n))
        for i in range(n):
            K[i, i] = 2
            if i > 0:
                K[i, i - 1] = -1
                K[i - 1, i] = -1

        a_exact = np.ones(n)
        R = K @ a_exact

        start_time = time.time()
        a, L, D = LDLTSolver.solve(K, R)
        solve_time = time.time() - start_time

        # 移除残差计算和打印
        # _, _, rel_res = LDLTSolver.residual_norm(K, a, R)
        rel_err = np.linalg.norm(a - a_exact) / np.linalg.norm(a_exact)

        print(f"  求解时间: {solve_time:.6f} s")
        # 移除残差打印
        # print(f"  相对残差: {rel_res:.6e}")
        print(f"  相对误差: {rel_err:.6e}")
        if n <= 10:
            print(f"  数值解: {a}")


def test_non_positive_definite():
    """算例2: 非正定矩阵检测"""
    print("\n" + "=" * 60)
    print("算例2: 非正定矩阵检测")
    print("=" * 60)

    K = np.array([[1, 2], [2, 1]])
    R = np.array([1, 1])

    print(f"测试矩阵:\n{K}")
    print(f"特征值: {np.linalg.eigvals(K)}")

    try:
        a, L, D = LDLTSolver.solve(K, R)
        print("LDLT分解成功 (不应该!)")
    except ValueError as e:
        print(f"正确检测到问题: {e}")

    print("\n说明: 有限元刚度矩阵在缺少足够位移边界条件时会出现零主元,")
    print("因为此时结构存在刚体位移, 刚度矩阵奇异.")


def test_sparse_vs_dense():
    """算例3: 稀疏与稠密求解器对比"""
    print("\n" + "=" * 60)
    print("算例3: 稀疏与稠密求解器对比")
    print("=" * 60)

    data = {
        "Title": "2D truss comparison",
        "nsd": 2, "ndof": 2, "nnp": 3, "nel": 2, "nen": 2,
        "E": [1, 1], "A": [1, 1],
        "x": [1, 0, 1], "y": [0, 0, 1],
        "IEN": [[1, 3], [2, 3]],
        "fixed_dof": [1, 2, 3, 4],
        "fixed_value": [0, 0, 0, 0],
        "force_dof": [5, 6],
        "force_value": [10, 0]
    }

    with open("input_2d_compare.json", "w") as f:
        json.dump(data, f, indent=2)

    print("\n--- 稠密LDLT求解器 ---")
    fea_dense = TrussFEAWithSolver()
    fea_dense.load_json("input_2d_compare.json")
    fea_dense.solve(method="ldlt", use_sparse=False)

    print("\n--- 稀疏求解器 ---")
    fea_sparse = TrussFEAWithSolver()
    fea_sparse.load_json("input_2d_compare.json")
    fea_sparse.solve(method="scipy_sparse", use_sparse=True)

    os.remove("input_2d_compare.json")

    return fea_dense.d, fea_sparse.d


def run_poisson_convergence():
    """算例4: Poisson方程网格收敛性分析"""
    print("\n" + "=" * 60)
    print("算例4: Poisson方程网格收敛性分析")
    print("=" * 60)

    mesh_sizes = [10, 20, 40]  # 使用较小网格确保运行
    results = []

    for nx in mesh_sizes:
        print(f"\n--- 网格: {nx} x {nx} ---")

        solver = PoissonFEMSolver(nx, nx, use_sparse=True)
        d, max_error, rel_l2_error = solver.solve()

        if nx <= 20:
            solver.plot_solution(f"poisson_solution_{nx}x{nx}.png")

        results.append({
            'nx': nx,
            'n_nodes': solver.n_nodes,
            'n_elements': solver.n_elements,
            'assembly_time': solver.assembly_time,
            'solve_time': solver.solve_time,
            'max_error': max_error,
            'rel_l2_error': rel_l2_error
        })

    print("\n" + "=" * 60)
    print("收敛性分析汇总")
    print("=" * 60)
    print(f"{'nx':>6} {'节点数':>8} {'单元数':>8} {'装配时间':>10} {'求解时间':>10} {'L2误差':>12}")
    print("-" * 70)

    for r in results:
        print(f"{r['nx']:6d} {r['n_nodes']:8d} {r['n_elements']:8d} "
              f"{r['assembly_time']:10.4f} {r['solve_time']:10.4f} {r['rel_l2_error']:12.2e}")

    return results


def run_2_3_truss_examples():
    """运行2.3作业的桁架验证算例"""
    print("\n" + "=" * 60)
    print("2.3作业桁架算例验证")
    print("=" * 60)

    # 一维杆算例
    print("\n--- 算例1: 一维两单元杆 ---")
    data_1d = {
        "Title": "1D two-element bar",
        "nsd": 1, "ndof": 1, "nnp": 3, "nel": 2, "nen": 2,
        "E": [100, 200], "A": [1, 1],
        "x": [0, 1, 2],
        "IEN": [[1, 2], [2, 3]],
        "fixed_dof": [1], "fixed_value": [0.0],
        "force_dof": [3], "force_value": [10.0]
    }
    with open("input_1d_solver.json", "w") as f:
        json.dump(data_1d, f, indent=2)

    fea_1d = TrussFEAWithSolver()
    fea_1d.load_json("input_1d_solver.json")
    fea_1d.solve(method="ldlt", use_sparse=False)

    # 二维桁架算例
    print("\n--- 算例2: 二维两杆桁架 ---")
    data_2d = {
        "Title": "2D truss",
        "nsd": 2, "ndof": 2, "nnp": 3, "nel": 2, "nen": 2,
        "E": [1, 1], "A": [1, 1],
        "x": [1, 0, 1], "y": [0, 0, 1],
        "IEN": [[1, 3], [2, 3]],
        "fixed_dof": [1, 2, 3, 4],
        "fixed_value": [0, 0, 0, 0],
        "force_dof": [5, 6],
        "force_value": [10, 0]
    }
    with open("input_2d_solver.json", "w") as f:
        json.dump(data_2d, f, indent=2)

    fea_2d = TrussFEAWithSolver()
    fea_2d.load_json("input_2d_solver.json")
    fea_2d.solve(method="ldlt", use_sparse=False)

    # 清理临时文件
    for f in ["input_1d_solver.json", "input_2d_solver.json"]:
        if os.path.exists(f):
            os.remove(f)

    return fea_1d.d, fea_2d.d


def main():
    """主函数: 运行所有测试算例"""
    print("=" * 60)
    print("有限元平衡方程组求解器")
    print("学号: 202311012102")
    print("姓名: 甘泽宇")
    print("=" * 60)

    # 2.3作业桁架算例
    run_2_3_truss_examples()

    # 任务1: 三对角矩阵测试
    run_tridiagonal_test()

    # 任务2: 病态矩阵分析
    ConditionNumberAnalyzer.analyze_ill_conditioned()

    # 任务2: 非正定矩阵检测
    test_non_positive_definite()

    # 任务3: 稀疏与稠密对比
    test_sparse_vs_dense()

    # 任务4: Poisson方程求解
    try:
        run_poisson_convergence()
    except MemoryError:
        print("\n注意: 内存不足, 使用更小网格")
        run_poisson_convergence_small()

    print("\n" + "=" * 60)
    print("所有测试完成!")
    print("=" * 60)


def run_poisson_convergence_small():
    """小规模Poisson方程测试"""
    print("\n--- 小规模Poisson方程测试 ---")

    mesh_sizes = [5, 10, 20]

    for nx in mesh_sizes:
        print(f"\n--- 网格: {nx} x {nx} ---")

        solver = PoissonFEMSolver(nx, nx, use_sparse=True)
        d, max_error, rel_l2_error = solver.solve()

        print(f"  L2误差: {rel_l2_error:.4e}")


if __name__ == "__main__":
    main()